import { Component } from '@angular/core';

@Component({
  selector: 'app-item-in-cart',
  imports: [],
  templateUrl: './item-in-cart.component.html',
  styleUrl: './item-in-cart.component.css'
})
export class ItemInCartComponent {

}
