import { Component } from '@angular/core';

@Component({
  selector: 'app-product-tile',
  imports: [],
  templateUrl: './product-tile.component.html',
  styleUrl: './product-tile.component.css'
})
export class ProductTileComponent {

}
