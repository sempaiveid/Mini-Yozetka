import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-form',
  imports: [],
  templateUrl: './admin-form.component.html',
  styleUrl: './admin-form.component.css'
})
export class AdminFormComponent {

}
