import { Component } from '@angular/core';

@Component({
  selector: 'header-input',
  imports: [],
  templateUrl: './header-input.component.html',
  styleUrl: './header-input.component.css'
})
export class HeaderInputComponent {

}
