import { Component } from '@angular/core';

@Component({
  selector: 'app-load-screen',
  imports: [],
  templateUrl: './load-screen.component.html',
  styleUrl: './load-screen.component.css'
})
export class LoadScreenComponent {

}
