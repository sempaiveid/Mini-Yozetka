import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductTileComponent } from '../../components/product-tile/product-tile.component';
import { AdsComponent } from '../../components/ads/ads.component';
import { CategorySidebarComponent } from '../../components/category-sidebar/category-sidebar.component';

@Component({
  selector: 'app-home',
  imports: [ProductTileComponent,AdsComponent,CategorySidebarComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  selectedCategory: string | null = null;
  selectedCategoryName: string | null = null;

  onCategoryChanged(category: any) {
    this.selectedCategory = category.key;
    this.selectedCategoryName = category.name;
  }

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      this.selectedCategory = id;
      this.selectedCategoryName = this.resolveCategoryName(id);
    });
  }

  resolveCategoryName(id: string | null): string | null {
    switch (id) {
      case 'device': return 'Техніка та інструменти';
      case 'cloth': return 'Одяг, взуття та прикрасси';
      case 'eat': return 'Їжа та напої';
      case 'food_pets': return 'Зоотовари';
      case 'chemic': return 'Побутова Хімія';
      default: return null;
    }
  }
}
